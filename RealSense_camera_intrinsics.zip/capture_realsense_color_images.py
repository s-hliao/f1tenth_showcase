from pathlib import Path
import cv2
import numpy as np

try:
    import pyrealsense2 as rs
except ImportError:
    rs = None


# ================= User settings =================

SAVE_DIR = Path("calibration")

# Your checkerboard:
# 6 squares by 9 squares means 5 by 8 INNER corners.
CHECKERBOARD_SIZE = (5, 8)

# Each physical square is 6.9 cm.
# This is not needed for saving images, but you will need it later for calibration.
SQUARE_SIZE_CM = 6.9

MAX_IMAGES = 25

# RealSense RGB stream settings.
WIDTH = 1280
HEIGHT = 720
FPS = 30

# Use RealSense D435i if True.
# Set to False if you want to use a normal webcam instead.
USE_REALSENSE = True
WEBCAM_INDEX = 0

# ==================================================


def get_next_image_number(save_dir: Path) -> int:
    """
    Finds the next available number based on files like:
    1_Color.png, 2_Color.png, ...
    """
    existing_numbers = []

    for path in save_dir.glob("*_Color.png"):
        name = path.stem  # example: "1_Color"
        first_part = name.split("_")[0]

        if first_part.isdigit():
            existing_numbers.append(int(first_part))

    if not existing_numbers:
        return 1

    return max(existing_numbers) + 1


def draw_overlay(frame, found_checkerboard: bool, image_number: int):
    status = "FOUND" if found_checkerboard else "NOT FOUND"

    cv2.putText(
        frame,
        f"Checkerboard: {status}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        (0, 255, 0) if found_checkerboard else (0, 0, 255),
        2,
        cv2.LINE_AA,
    )

    cv2.putText(
        frame,
        f"Next save: {image_number}_Color.png",
        (20, 80),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )

    cv2.putText(
        frame,
        "Press t = take picture | q = quit",
        (20, 120),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )


def run_realsense_capture():
    if rs is None:
        raise RuntimeError(
            "pyrealsense2 is not installed. Run this first:\n"
            "pip install pyrealsense2"
        )

    pipeline = rs.pipeline()
    config = rs.config()

    config.enable_stream(
        rs.stream.color,
        WIDTH,
        HEIGHT,
        rs.format.bgr8,
        FPS,
    )

    print("Starting RealSense RGB camera...")
    pipeline.start(config)

    # Let auto exposure settle.
    for _ in range(30):
        pipeline.wait_for_frames()

    next_number = get_next_image_number(SAVE_DIR)

    print("Camera started.")
    print("Press t to take a picture.")
    print("Press q to quit.")

    try:
        while True:
            frames = pipeline.wait_for_frames()
            color_frame = frames.get_color_frame()

            if not color_frame:
                continue

            frame = np.asanyarray(color_frame.get_data())
            display = frame.copy()

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            found, corners = cv2.findChessboardCorners(
                gray,
                CHECKERBOARD_SIZE,
                flags=cv2.CALIB_CB_ADAPTIVE_THRESH
                + cv2.CALIB_CB_NORMALIZE_IMAGE
                + cv2.CALIB_CB_FAST_CHECK,
            )

            if found:
                cv2.drawChessboardCorners(
                    display,
                    CHECKERBOARD_SIZE,
                    corners,
                    found,
                )

            draw_overlay(display, found, next_number)

            cv2.imshow("RealSense Color Camera", display)

            key = cv2.waitKey(1) & 0xFF

            if key == ord("q"):
                print("Quitting.")
                break

            if key == ord("t"):
                if next_number > MAX_IMAGES:
                    print(f"Already saved {MAX_IMAGES} images. Not saving more.")
                    continue

                filename = SAVE_DIR / f"{next_number}_Color.png"
                cv2.imwrite(str(filename), frame)

                print(f"Saved: {filename}")

                next_number += 1

                if next_number > MAX_IMAGES:
                    print(f"Reached {MAX_IMAGES} images.")
                    print("Press q to quit, or delete images if you want to retake.")

    finally:
        pipeline.stop()
        cv2.destroyAllWindows()


def run_webcam_capture():
    cap = cv2.VideoCapture(WEBCAM_INDEX, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
    cap.set(cv2.CAP_PROP_FPS, FPS)

    if not cap.isOpened():
        raise RuntimeError("Could not open webcam.")

    next_number = get_next_image_number(SAVE_DIR)

    print("Webcam started.")
    print("Press t to take a picture.")
    print("Press q to quit.")

    try:
        while True:
            ok, frame = cap.read()

            if not ok:
                continue

            display = frame.copy()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            found, corners = cv2.findChessboardCorners(
                gray,
                CHECKERBOARD_SIZE,
                flags=cv2.CALIB_CB_ADAPTIVE_THRESH
                + cv2.CALIB_CB_NORMALIZE_IMAGE
                + cv2.CALIB_CB_FAST_CHECK,
            )

            if found:
                cv2.drawChessboardCorners(
                    display,
                    CHECKERBOARD_SIZE,
                    corners,
                    found,
                )

            draw_overlay(display, found, next_number)

            cv2.imshow("Webcam Color Camera", display)

            key = cv2.waitKey(1) & 0xFF

            if key == ord("q"):
                print("Quitting.")
                break

            if key == ord("t"):
                if next_number > MAX_IMAGES:
                    print(f"Already saved {MAX_IMAGES} images. Not saving more.")
                    continue

                filename = SAVE_DIR / f"{next_number}_Color.png"
                cv2.imwrite(str(filename), frame)

                print(f"Saved: {filename}")

                next_number += 1

                if next_number > MAX_IMAGES:
                    print(f"Reached {MAX_IMAGES} images.")
                    print("Press q to quit, or delete images if you want to retake.")

    finally:
        cap.release()
        cv2.destroyAllWindows()


def main():
    SAVE_DIR.mkdir(parents=True, exist_ok=True)

    print("Checkerboard physical size:")
    print("  Squares: 6 by 9")
    print("  OpenCV inner corners:", CHECKERBOARD_SIZE)
    print("  Square size:", SQUARE_SIZE_CM, "cm")
    print("Saving images to:", SAVE_DIR.resolve())

    if USE_REALSENSE:
        run_realsense_capture()
    else:
        run_webcam_capture()


if __name__ == "__main__":
    main()