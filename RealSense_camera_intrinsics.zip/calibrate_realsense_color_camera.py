from pathlib import Path
import json

import cv2
import numpy as np


# ================= User settings =================

CALIBRATION_DIR = Path("calibration")

# Your checkerboard is 6 squares by 9 squares.
# OpenCV uses INNER corners, so this is 5 by 8.
CHECKERBOARD_SIZE = (5, 8)

# Each physical square is 6.9 cm.
SQUARE_SIZE_CM = 6.9

# Output files
OUTPUT_NPZ = Path("camera_intrinsics_color.npz")
OUTPUT_JSON = Path("camera_intrinsics_color.json")
ANNOTATED_DIR = Path("calibration_annotated")

# ==================================================


def list_calibration_images(folder: Path) -> list[Path]:
    valid_suffixes = {".png", ".jpg", ".jpeg", ".bmp"}

    image_paths = [
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() in valid_suffixes
    ]

    def sort_key(path: Path):
        # Sort 1_Color.png, 2_Color.png, ..., 25_Color.png numerically.
        first_part = path.stem.split("_")[0]
        if first_part.isdigit():
            return int(first_part)
        return 999999

    return sorted(image_paths, key=sort_key)


def build_object_points(pattern_size: tuple[int, int], square_size_cm: float) -> np.ndarray:
    """
    Build 3D object points for the checkerboard corners.

    The checkerboard is assumed to lie on the Z=0 plane.

    For pattern_size = (5, 8), this creates:

        (0, 0, 0), (6.9, 0, 0), ..., 
        ...
        in centimeters.
    """
    cols, rows = pattern_size

    objp = np.zeros((rows * cols, 3), np.float32)

    objp[:, :2] = np.mgrid[0:cols, 0:rows].T.reshape(-1, 2)

    objp *= square_size_cm

    return objp


def detect_checkerboard_corners(
    image: np.ndarray,
    pattern_size: tuple[int, int],
):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    found, corners = cv2.findChessboardCorners(
        gray,
        pattern_size,
        flags=cv2.CALIB_CB_ADAPTIVE_THRESH
        + cv2.CALIB_CB_NORMALIZE_IMAGE
        + cv2.CALIB_CB_FAST_CHECK,
    )

    if not found:
        return False, None, gray

    criteria = (
        cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
        30,
        0.001,
    )

    corners_refined = cv2.cornerSubPix(
        gray,
        corners,
        winSize=(11, 11),
        zeroZone=(-1, -1),
        criteria=criteria,
    )

    return True, corners_refined, gray


def calibrate_with_pattern(
    image_paths: list[Path],
    pattern_size: tuple[int, int],
    square_size_cm: float,
):
    object_points = []
    image_points = []
    used_images = []
    image_size = None

    objp = build_object_points(pattern_size, square_size_cm)

    ANNOTATED_DIR.mkdir(parents=True, exist_ok=True)

    for image_path in image_paths:
        image = cv2.imread(str(image_path))

        if image is None:
            print(f"Could not read image: {image_path}")
            continue

        found, corners, gray = detect_checkerboard_corners(image, pattern_size)

        image_size = (gray.shape[1], gray.shape[0])

        annotated = image.copy()

        if found:
            object_points.append(objp.copy())
            image_points.append(corners)
            used_images.append(image_path)

            cv2.drawChessboardCorners(
                annotated,
                pattern_size,
                corners,
                found,
            )

            print(f"[OK] Found checkerboard in {image_path.name}")
        else:
            print(f"[FAIL] Checkerboard not found in {image_path.name}")

        out_path = ANNOTATED_DIR / f"annotated_{image_path.name}"
        cv2.imwrite(str(out_path), annotated)

    if len(image_points) < 5:
        raise RuntimeError(
            f"Only {len(image_points)} usable images found for pattern {pattern_size}. "
            "Need at least 5, preferably 15-25."
        )

    reproj_error, camera_matrix, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(
        object_points,
        image_points,
        image_size,
        None,
        None,
    )

    return {
        "pattern_size": pattern_size,
        "square_size_cm": square_size_cm,
        "object_points": object_points,
        "image_points": image_points,
        "used_images": used_images,
        "image_size": image_size,
        "reproj_error": reproj_error,
        "camera_matrix": camera_matrix,
        "dist_coeffs": dist_coeffs,
        "rvecs": rvecs,
        "tvecs": tvecs,
    }


def compute_per_image_reprojection_errors(result: dict) -> list[float]:
    camera_matrix = result["camera_matrix"]
    dist_coeffs = result["dist_coeffs"]
    rvecs = result["rvecs"]
    tvecs = result["tvecs"]
    object_points = result["object_points"]
    image_points = result["image_points"]

    errors = []

    for i in range(len(object_points)):
        projected_points, _ = cv2.projectPoints(
            object_points[i],
            rvecs[i],
            tvecs[i],
            camera_matrix,
            dist_coeffs,
        )

        error = cv2.norm(
            image_points[i],
            projected_points,
            cv2.NORM_L2,
        ) / len(projected_points)

        errors.append(float(error))

    return errors


def save_results(result: dict, per_image_errors: list[float]) -> None:
    camera_matrix = result["camera_matrix"]
    dist_coeffs = result["dist_coeffs"]
    pattern_size = result["pattern_size"]
    image_size = result["image_size"]
    used_images = result["used_images"]

    fx = camera_matrix[0, 0]
    fy = camera_matrix[1, 1]
    cx = camera_matrix[0, 2]
    cy = camera_matrix[1, 2]

    np.savez(
        OUTPUT_NPZ,
        camera_matrix=camera_matrix,
        dist_coeffs=dist_coeffs,
        image_size=np.array(image_size),
        pattern_size=np.array(pattern_size),
        square_size_cm=np.array([result["square_size_cm"]]),
        reproj_error=np.array([result["reproj_error"]]),
        per_image_errors=np.array(per_image_errors),
        used_images=np.array([str(p) for p in used_images]),
    )

    json_data = {
        "image_size": {
            "width": int(image_size[0]),
            "height": int(image_size[1]),
        },
        "checkerboard": {
            "physical_squares": "6 by 9",
            "inner_corners_used": [int(pattern_size[0]), int(pattern_size[1])],
            "square_size_cm": float(result["square_size_cm"]),
        },
        "intrinsics": {
            "fx": float(fx),
            "fy": float(fy),
            "cx": float(cx),
            "cy": float(cy),
            "camera_matrix": camera_matrix.tolist(),
        },
        "distortion": {
            "dist_coeffs": dist_coeffs.ravel().tolist(),
            "note": "OpenCV distortion coefficients, usually k1, k2, p1, p2, k3 for this calibration.",
        },
        "calibration_quality": {
            "opencv_reprojection_error": float(result["reproj_error"]),
            "per_image_reprojection_errors": per_image_errors,
            "num_images_used": len(used_images),
            "used_images": [p.name for p in used_images],
        },
    }

    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(json_data, f, indent=4)

    print("\n================ Calibration Result ================")
    print(f"Images used: {len(used_images)}")
    print(f"Image size: {image_size[0]} x {image_size[1]}")
    print(f"Checkerboard inner corners used: {pattern_size}")
    print(f"Square size: {result['square_size_cm']} cm")
    print(f"OpenCV reprojection error: {result['reproj_error']:.6f}")

    print("\nCamera matrix K:")
    print(camera_matrix)

    print("\nIntrinsics:")
    print(f"fx = {fx:.6f}")
    print(f"fy = {fy:.6f}")
    print(f"cx = {cx:.6f}")
    print(f"cy = {cy:.6f}")

    print("\nDistortion coefficients:")
    print(dist_coeffs.ravel())

    print("\nPer-image reprojection errors:")
    for image_path, error in zip(used_images, per_image_errors):
        print(f"  {image_path.name}: {error:.6f}")

    print("\nSaved:")
    print(f"  {OUTPUT_NPZ.resolve()}")
    print(f"  {OUTPUT_JSON.resolve()}")
    print(f"  Annotated images: {ANNOTATED_DIR.resolve()}")


def main():
    if not CALIBRATION_DIR.exists():
        raise FileNotFoundError(f"Calibration directory not found: {CALIBRATION_DIR}")

    image_paths = list_calibration_images(CALIBRATION_DIR)

    if not image_paths:
        raise FileNotFoundError(f"No calibration images found in: {CALIBRATION_DIR}")

    print(f"Found {len(image_paths)} calibration images.")

    # Try both possible orderings.
    # Your board should be (5, 8), but trying (8, 5) helps catch orientation/order mistakes.
    candidate_patterns = [
        CHECKERBOARD_SIZE,
        (CHECKERBOARD_SIZE[1], CHECKERBOARD_SIZE[0]),
    ]

    results = []

    for pattern in candidate_patterns:
        print("\n====================================================")
        print(f"Trying checkerboard inner-corner pattern: {pattern}")
        print("====================================================")

        try:
            result = calibrate_with_pattern(
                image_paths=image_paths,
                pattern_size=pattern,
                square_size_cm=SQUARE_SIZE_CM,
            )
            results.append(result)
        except RuntimeError as e:
            print(f"Pattern {pattern} failed: {e}")

    if not results:
        raise RuntimeError("Calibration failed for all checkerboard pattern candidates.")

    # Prefer the result that uses more images.
    # If tied, prefer lower reprojection error.
    results.sort(
        key=lambda r: (-len(r["used_images"]), r["reproj_error"])
    )

    best = results[0]
    per_image_errors = compute_per_image_reprojection_errors(best)

    save_results(best, per_image_errors)


if __name__ == "__main__":
    main()